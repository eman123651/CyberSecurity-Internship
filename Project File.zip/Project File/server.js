let usersData = [
    {
        userEmail: "azhar40@live.co.uk",
        userPassword: "azharkhan",
        userName: "Azhar khan",
        userPosts : [],
    },
]

var currentUser;
const validator = require('validator');
var express = require("express");
var bodyParser = require('body-parser');
var cors = require("cors");
var morgan = require("morgan");
const helmet = require("helmet");
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");
const winston = require('winston');

// Create Logger
const logger = winston.createLogger({
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({
            filename: 'security.log'
        })
    ]
});
logger.info('Application started');
console.log("Logger executed");

var server = express();
server.use(helmet());
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({
    extended: true
}));
server.use(cors());
server.use(morgan('dev'))

const PORT = process.env.PORT || 3000;


server.post("/signup", async (req, res, next) => {

    var currEmail = req.body.userEmail;
    var found = false;
    if (!validator.isEmail(currEmail)) {
    return res.send({
        message: "Invalid Email",
        status: 400
    });
}

    for (var i = 0; i < usersData.length; i++) {
        if (usersData[i].userEmail === currEmail) {
            found = true;
            break;
        }
    }
    if (found) {
        res.send(
            {
                message: "Email already exsist",
                status: 400,
            })
    }
   else {

    const hashedPassword = await bcrypt.hash(req.body.userPassword, 10);

    usersData.push({
        userEmail: req.body.userEmail,
        userPassword: hashedPassword,
        userName: req.body.userName,
        userPosts: []
    });
    logger.info('New user signup');

    res.send({
        message: "Signed up succesfully",
        status: 200,
    });
}
});

server.post("/login", async function (req, res, next) {

    let obj = req.body;
    let found = false;

    for (var i = 0; i < usersData.length; i++) {
        if (usersData[i].userEmail === obj.email) {
            found = i;
            currentUser = found;
            break;
        }
    }

    if (found === false) {
        return res.send({
            message: "Email or password is wrong",
            status: 400,
        });
    }

    const match = await bcrypt.compare(
        obj.password,
        usersData[found].userPassword
    );

    if (!match) {
        return res.send({
            message: "Email or password is wrong",
            status: 400,
        });
    }

    const token = jwt.sign(
        {
            email: obj.email
        },
        "my-secret-key",
        { expiresIn: "1h" }
    );

    logger.info('User logged in: ' + obj.email);

    res.send({
        message: "Signed in successfully",
        status: 200,
        currentUser: found,
        token: token
    });

});

server.get("/successfullSignup", (req, res, next) => {

    res.send(usersData);


});
server.get("/login", (req, res) => {
    res.send("Login page use POST request");
});

server.post("/userPost", (req,res,next)=>{
    
    let reqBody = req.body;
    console.log(usersData);
    usersData[reqBody.currentUser].userPosts.push(reqBody.userPost);
    res.send(usersData);


})



server.listen(PORT, () => {
    console.log("server is runnin on port " + PORT);

})
